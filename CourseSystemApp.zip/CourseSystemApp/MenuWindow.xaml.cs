﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CourseSystemApp
{
    /// <summary>
    /// MenuWindow.xaml 的互動邏輯
    /// </summary>
    public partial class MenuWindow : Window
    {
        public MenuWindow()
        {
            InitializeComponent();
            this.Loaded += MenuWindow_Loaded;
        }

        private void MenuWindow_Loaded(object sender, RoutedEventArgs e)
        {
            this.User.Text =$"目前登入者:{((App)Application.Current).CurrentUser.UserName}" ;
        }

        private void PwdFun_Click(object sender, RoutedEventArgs e)
        {
            this.FunFrame.Navigate(new System.Uri("PwdFunPage.xaml", UriKind.RelativeOrAbsolute));
        }

        private void LogoutFun_Click(object sender, RoutedEventArgs e)
        {
            ((App)Application.Current).CurrentUser = null;
            var login = new MainWindow();
            login.Show();
            this.Close();
        }

        private void AdminFun_Click(object sender, RoutedEventArgs e)
        {
            this.FunFrame.Navigate(new System.Uri("AdminFunPage.xaml", UriKind.RelativeOrAbsolute));
        }

        private void TestBtn_Click(object sender, RoutedEventArgs e)
        {
            //連續關閉父子window
            TestWindow subWindow = new TestWindow(this);
            subWindow.ShowDialog();
        }

        private void CourseScheduleFun_Click(object sender, RoutedEventArgs e)
        {
            this.FunFrame.Navigate(new System.Uri("CourseScheduleFunPage.xaml", UriKind.RelativeOrAbsolute));
        }
    }
}
