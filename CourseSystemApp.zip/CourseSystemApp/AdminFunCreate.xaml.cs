﻿using CourseSystemApp.Helper;
using CourseSystemLibrary.DataModels;
using CourseSystemLibrary.DbService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CourseSystemApp
{
    /// <summary>
    /// AdminFunCreate.xaml 的互動邏輯
    /// </summary>
    public partial class AdminFunCreate : Window
    {
        private readonly string _dbConnStr;
        private AdminUserInfo _adminUserInfo;
        public AdminFunCreate()
        {
            InitializeComponent();
            _dbConnStr = ((App)Application.Current).DbConnStr;
            _adminUserInfo = new AdminUserInfo();
            this.DataContext = _adminUserInfo;
        }

        private void CreateBtn_Click(object sender, RoutedEventArgs e)
        {
            var service = new AdminUserRepository(_dbConnStr);
            //必填
            if (string.IsNullOrEmpty(_adminUserInfo.UserName))
            {
                MessageBox.Show("管理員帳號必填");
                return;
            }

            var user = service.GetAdminUser(_adminUserInfo.UserName);
            if (user != null)
            {
                MessageBox.Show("管理員帳號重覆");
                return;
            }

            //密碼hash
            _adminUserInfo.Id = Guid.NewGuid();
            _adminUserInfo.Password = LoginHelper.PwdHash("123456", _adminUserInfo.Id.ToString());
            service.CreateAdminUser(_adminUserInfo);
            MessageBox.Show("資料新增成功");

            _adminUserInfo = new AdminUserInfo();
            this.DataContext = _adminUserInfo;

        }
    }
}
