﻿using CourseSystemLibrary.DataModels;
using CourseSystemLibrary.DbService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CourseSystemApp
{
    /// <summary>
    /// Interaction logic for CourseScheduleFunCreate.xaml
    /// </summary>
    public partial class CourseScheduleFunCreate : Window
    {
        private readonly string _dbConnStr;
        private CourseScheduleCreateModel _newCourseSchedule;

        public CourseScheduleFunCreate()
        {
            InitializeComponent();
            _dbConnStr = ((App)Application.Current).DbConnStr;
            _newCourseSchedule = new CourseScheduleCreateModel();
            this.DataContext = _newCourseSchedule;

            this.Loaded += CourseScheduleFunCreate_Loaded;
        }

        private void CourseScheduleFunCreate_Loaded(object sender, RoutedEventArgs e)
        {
            var cousreService = new CourseRepository(_dbConnStr);
            this.CourseCombo.ItemsSource = cousreService.Query();

            var teaService = new TeacherRepository(_dbConnStr);
            this.TeacherCombo.ItemsSource = teaService.Query();
        }

        private void CreateBtn_Click(object sender, RoutedEventArgs e)
        {
            if (_newCourseSchedule.Cid == Guid.Empty 
                || _newCourseSchedule.Tid == Guid.Empty
                || string.IsNullOrEmpty(_newCourseSchedule.Location))
            {
                MessageBox.Show("課程/講師/課程地點 必填");
                return;
            }

            if (_newCourseSchedule.Edate<_newCourseSchedule.Sdate)
            {
                MessageBox.Show("課程結束日期必須＞＝開始日期");
                return;
            }

            if (_newCourseSchedule.Sdate.Date < DateTime.Now.Date)
            {
                MessageBox.Show("課程開始日期必須＞＝今天");
                return;
            }


            var service = new CourseScheduleRepository(_dbConnStr);

            //驗證重覆開課
            var check = service.CourseExistByTeacher(_newCourseSchedule.Tid, _newCourseSchedule.Cid, 
                _newCourseSchedule.Sdate, _newCourseSchedule.Edate);

            if (check)
            {
                MessageBox.Show("重覆開課");
                return;
            }

            service.CreateCourseSchedule(_newCourseSchedule);
            MessageBox.Show("資料新增成功");

            _newCourseSchedule = new CourseScheduleCreateModel();
            this.DataContext = _newCourseSchedule;
        }
    }
}
