﻿using CourseSystemLibrary.DataModels;
using CourseSystemLibrary.DbService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CourseSystemApp
{
    /// <summary>
    /// Interaction logic for CourseScheduleFunEdit.xaml
    /// </summary>
    public partial class CourseScheduleFunEdit : Window
    {
        private readonly string _dbConnStr;
        public CourseScheduleFunEdit()
        {
            InitializeComponent();
            _dbConnStr = ((App)Application.Current).DbConnStr;
        }

        private void SaveBtn_Click(object sender, RoutedEventArgs e)
        {
            if (this.DataContext == null)
            {
                MessageBox.Show("未選擇任何資料");
                return;
            }

            var courseSchedule = (CourseScheduleInfo)this.DataContext;
            var service = new CourseScheduleRepository(_dbConnStr);
            service.UpdateSchedule(courseSchedule);
            MessageBox.Show("資料更新成功");
        }
    }
}
