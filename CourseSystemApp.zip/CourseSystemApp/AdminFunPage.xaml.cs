﻿using CourseSystemLibrary.DataModels;
using CourseSystemLibrary.DbService;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CourseSystemApp
{
    /// <summary>
    /// AdminFunPage.xaml 的互動邏輯
    /// </summary>
    public partial class AdminFunPage : Page
    {
        private readonly string _dbConnStr;

        private ObservableCollection<AdminUserInfo> _adminUserList { get; set; }

        public AdminFunPage()
        {
            InitializeComponent();
            _dbConnStr = ((App)Application.Current).DbConnStr;
        }

        private void QueryButton_Click(object sender, RoutedEventArgs e)
        {
            Query();
        }

        private void CreateButton_Click(object sender, RoutedEventArgs e)
        {
            var create = new AdminFunCreate();
            create.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            create.ShowDialog();
            Query();
        }

        private void Query()
        {
            var service = new AdminUserRepository(_dbConnStr);
            _adminUserList = service.Query(
                new AdminUserQueryParameter() { UserName = this.UserName.Text, Email = this.Email.Text }
                );
            this.UserList.ItemsSource = _adminUserList;
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            var btn = sender as Button;
            var adminUser = btn.CommandParameter as AdminUserInfo;

            var editWin = new AdminFunEdit(adminUser);
            editWin.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            editWin.ShowDialog();
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            var btn = sender as Button;
            var adminUser = btn.CommandParameter as AdminUserInfo;

            var result = MessageBox.Show($"確認要刪除 {adminUser.UserName}?", "Confirm Delete", MessageBoxButton.YesNo, MessageBoxImage.Warning);
          
            if (result == MessageBoxResult.Yes)
            {
                //選到目前登入者資料，不予刪除
                var currentUser = ((App)Application.Current).CurrentUser;
                if (currentUser.Id == adminUser.Id)
                {
                    MessageBox.Show("有事好好說，不要自殺");
                    return;
                }

                var service = new AdminUserRepository(_dbConnStr);
                service.DeleteAdminUser(adminUser.Id);
                MessageBox.Show("資料刪除成功");
                
                Query();
            }
        }
    }
}
