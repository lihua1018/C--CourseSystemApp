﻿using CourseSystemLibrary.DataModels;
using CourseSystemLibrary.DbService;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CourseSystemApp
{
    /// <summary>
    /// Interaction logic for CourseScheduleFunPage.xaml
    /// </summary>
    public partial class CourseScheduleFunPage : Page
    {
        private string _dbConnStr;
        private ObservableCollection<CourseScheduleInfo> _courseList { get; set; }
        public CourseScheduleFunPage()
        {
            InitializeComponent();
            _dbConnStr = ((App)Application.Current).DbConnStr;
        }

        private void Query()
        {
            var service = new CourseScheduleRepository(_dbConnStr);

            _courseList = service.Query(
                new CourseScheduleQueryParameter()
                {
                    CourseName = this.Query_CourseName.Text,
                    TeacherName = this.Query_TeacherName.Text
                });
            this.CourseScheduleList.ItemsSource = _courseList;
        }

        private void QueryButton_Click(object sender, RoutedEventArgs e)
        {
            Query();
        }

        private void CreateButton_Click(object sender, RoutedEventArgs e)
        {
            var create = new CourseScheduleFunCreate();
            create.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            create.ShowDialog();
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            var btn = sender as Button;
            var courseScheduleInfo = btn.CommandParameter as CourseScheduleInfo;

            var editWin = new CourseScheduleFunEdit();
            editWin.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            editWin.DataContext = courseScheduleInfo;
            editWin.ShowDialog();
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            var btn = sender as Button;
            var courseScheduleInfo = btn.CommandParameter as CourseScheduleInfo;

            var result = MessageBox.Show($"確認要刪除 {courseScheduleInfo.CourseName} ({courseScheduleInfo.Code})?", "Confirm Delete", MessageBoxButton.YesNo, MessageBoxImage.Warning);

            if (result == MessageBoxResult.Yes)
            {
                //無人選課才能刪除
                var stuservice = new StuScheduleRepository(_dbConnStr);
                if (stuservice.StuScheduleExist(courseScheduleInfo.Id))
                {
                    MessageBox.Show("已有學員選課，無法刪除");
                    return;
                }

                var service = new CourseScheduleRepository(_dbConnStr);
                service.DeleteSchedule(courseScheduleInfo.Id);
                MessageBox.Show("資料刪除成功");
                Query();
            }
        }
    }
}
