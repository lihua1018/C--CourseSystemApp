﻿using CourseSystemApp.Helper;
using CourseSystemLibrary.DbService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CourseSystemApp
{
    /// <summary>
    /// MainWindow.xaml 的互動邏輯
    /// </summary>
    public partial class MainWindow : Window
    {
        private string _dbConnStr;
        public MainWindow()
        {
            InitializeComponent();

            _dbConnStr = ((App)Application.Current).DbConnStr;
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            //1.驗必填
            if (string.IsNullOrEmpty(this.UserName.Text) || string.IsNullOrEmpty(this.Pwd.Password))
            {
                MessageBox.Show("請輸入帳號及密碼", "訊息", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            //2.驗帳號是否存在
            var dbService = new AdminUserRepository(_dbConnStr);
            var adminUser = dbService.GetAdminUser(this.UserName.Text);
            if (adminUser == null)
            {
                MessageBox.Show("登入失敗", "訊息", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            //3.驗證密碼
            var pwdHash = LoginHelper.PwdHash(this.Pwd.Password, adminUser.Id.ToString());
            if (pwdHash != adminUser.Password)
            {
                MessageBox.Show("登入失敗", "訊息", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            //4.Keep Current User
            var app = (App)Application.Current;
            app.CurrentUser = adminUser;

            //5.Direct to Menu Window
            var menuWindow = new MenuWindow();
            menuWindow.Show();
            this.Close();
        }
    }
}
