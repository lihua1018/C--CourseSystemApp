﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CourseSystemApp
{
    /// <summary>
    /// TestWindow.xaml 的互動邏輯
    /// </summary>
    public partial class TestWindow : Window
    {
        private Window _parentWindow;
        public TestWindow(Window parentWindow)
        {
            InitializeComponent();
            _parentWindow = parentWindow;
        }

        private void CloseBtn_Click(object sender, RoutedEventArgs e)
        {
            ((App)Application.Current).CurrentUser = null;
            var login = new MainWindow();
            login.Show();

            _parentWindow.Close();
            this.Close();
        }
    }
}
