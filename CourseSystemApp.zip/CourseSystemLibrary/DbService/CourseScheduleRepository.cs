﻿using CourseSystemLibrary.DataModels;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseSystemLibrary.DbService
{
    public class CourseScheduleRepository
    {
        private string _dbConnString;
        public CourseScheduleRepository(string dbConnString)
        {
            _dbConnString = dbConnString;
        }

        public void CreateCourseSchedule(CourseScheduleCreateModel courseScheduleCreateModel)
        {
            using (var conn = new SqlConnection(_dbConnString))
            {
                var cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandText = @"insert into courseschedule (id,courseid,teacherid,sdate,edate,location) 
                                    values(@id,@courseid,@teacherid,@sdate,@edate,@location) ";

                cmd.Parameters.AddWithValue("@id", courseScheduleCreateModel.Id);
                cmd.Parameters.AddWithValue("@courseid", courseScheduleCreateModel.Cid);
                cmd.Parameters.AddWithValue("@teacherid", courseScheduleCreateModel.Tid);
                cmd.Parameters.AddWithValue("@sdate", courseScheduleCreateModel.Sdate.ToShortDateString());
                cmd.Parameters.AddWithValue("@edate", courseScheduleCreateModel.Edate.ToShortDateString());
                cmd.Parameters.AddWithValue("@location", courseScheduleCreateModel.Location);

                cmd.Connection.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public bool CourseExistByTeacher(Guid tId, Guid cId, DateTime sDate, DateTime eDate)
        {
            using (var conn = new SqlConnection(_dbConnString))
            {
                var cmd = new SqlCommand();

                string querySql = @"select id from courseschedule 
                                where teacherid=@teacherid 
                                and courseid=@courseid 
                                and @sdate <=edate
                                and @edate >=sdate";
                cmd.CommandText = querySql;
                cmd.Parameters.AddWithValue("@teacherid", tId);
                cmd.Parameters.AddWithValue("@courseid", cId);
                cmd.Parameters.AddWithValue("@sdate", sDate.ToShortDateString());
                cmd.Parameters.AddWithValue("@edate", eDate.ToShortDateString());

                cmd.Connection = conn;
                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    return true;
                }
            }
            return false;
        }

        public ObservableCollection<CourseScheduleInfo> Query(CourseScheduleQueryParameter para)
        {
            var courseList = new ObservableCollection<CourseScheduleInfo>();

            using (var conn = new SqlConnection(_dbConnString))
            {
                var cmd = new SqlCommand();

                string querySql = @"select schedule.id,course.code,course.name as coursename,teacher.name as teachername
                                    ,schedule.sdate,schedule.edate,course.times,schedule.location,course.description
                                    from courseschedule as schedule
                                    inner join course on schedule.courseid=course.id
                                    inner join teacher on schedule.teacherid=teacher.id ";

                string where = string.Empty;

                if (!string.IsNullOrEmpty(para.CourseName))
                {
                    where += " course.name like @coursename ";

                    cmd.Parameters.AddWithValue("@coursename", $"%{para.CourseName}%");
                }

                if (!string.IsNullOrEmpty(para.TeacherName))
                {
                    if (!string.IsNullOrEmpty(where))
                    {
                        where += " and ";
                    }

                    where += " teacher.name like @teachername ";

                    cmd.Parameters.AddWithValue("@teachername", $"%{para.TeacherName}%");
                }

                if (!string.IsNullOrEmpty(where))
                {
                    querySql += " where " + where;
                }
                querySql += " order by schedule.sdate desc";
                cmd.CommandText = querySql;
                cmd.Connection = conn;
                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    courseList.Add(new CourseScheduleInfo()
                    {
                        Id = Guid.Parse(dr["id"].ToString()),
                        Code = dr["code"].ToString(),
                        CourseName = dr["coursename"].ToString(),
                        TeacherName = dr["teachername"].ToString(),
                        Sdate = DateTime.Parse(dr["sdate"].ToString()),
                        Edate = DateTime.Parse(dr["edate"].ToString()),
                        Times = int.Parse(dr["times"].ToString()),
                        Location = dr["location"].ToString(),
                        Description = dr["description"].ToString()
                    });
                }
            }

            return courseList;
        }

        public void DeleteSchedule(Guid courseScheduleId)
        {
            using (var conn = new SqlConnection(_dbConnString))
            {
                var cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandText = "delete courseschedule where id=@id";
                cmd.Parameters.AddWithValue("@id", courseScheduleId);
                cmd.Connection.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void UpdateSchedule(CourseScheduleInfo courseScheduleInfo)
        {
            using (var conn = new SqlConnection(_dbConnString))
            {
                var cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandText = "update courseschedule set sdate=@sdate,edate=@edate where id=@id";
                cmd.Parameters.AddWithValue("@id", courseScheduleInfo.Id);
                cmd.Parameters.AddWithValue("@sdate", courseScheduleInfo.Sdate.ToShortDateString());
                cmd.Parameters.AddWithValue("@edate", courseScheduleInfo.Edate.ToShortDateString());
                cmd.Connection.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }


    public class CourseScheduleQueryParameter
    {
        public string CourseName { get; set; }
        public string TeacherName { get; set; }
    }
}
