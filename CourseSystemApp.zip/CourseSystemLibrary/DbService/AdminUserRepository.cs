﻿using CourseSystemLibrary.DataModels;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseSystemLibrary.DbService
{
    public class AdminUserRepository
    {
        private readonly string _dbConnString;

        public AdminUserRepository(string dbConnString)
        {
            _dbConnString = dbConnString;
        }

        public AdminUserInfo GetAdminUser(string username)
        {
            AdminUserInfo user = null;

            //query db

            using (var conn = new SqlConnection(_dbConnString))
            {
                var cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandText = "select id,username,password,email from sysadmin where username=@user";
                cmd.Parameters.AddWithValue("user", username);
                cmd.Connection.Open();
                var dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    user = new AdminUserInfo()
                    {
                        Id = Guid.Parse(dr["id"].ToString()),
                        UserName = dr["username"].ToString(),
                        Email = dr["email"].ToString(),
                        Password = dr["password"].ToString()
                    };
                }
                dr.Close();
            }

            return user;
        }

        public void UpdatePwd(Guid userId, string newPwd)
        {
            using (var conn = new SqlConnection(_dbConnString))
            {
                var cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandText = "update sysadmin set password=@password where id=@id";
                cmd.Parameters.AddWithValue("@id", userId);
                cmd.Parameters.AddWithValue("@password", newPwd);
                cmd.Connection.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public ObservableCollection<AdminUserInfo> Query(AdminUserQueryParameter parameter)
        {
            var userList = new ObservableCollection<AdminUserInfo>();

            string queryString = "select id,username,password,email from sysadmin ";
            string whereString = string.Empty;

            using (var conn = new SqlConnection(_dbConnString))
            {
                var cmd = new SqlCommand();
                cmd.Connection = conn;

                if (!string.IsNullOrEmpty(parameter.UserName))
                {
                    //whereString += " username=@username ";
                    //cmd.Parameters.AddWithValue("@username", parameter.UserName);

                    whereString += " username like @username ";
                    cmd.Parameters.AddWithValue("@username", $"%{parameter.UserName}%");

                }

                if (!string.IsNullOrEmpty(parameter.Email))
                {
                    if (!string.IsNullOrEmpty(whereString))
                    {
                        whereString += " and ";
                    }

                    whereString += " email=@email ";
                    cmd.Parameters.AddWithValue("@email", parameter.Email);
                }

                if (!string.IsNullOrEmpty(whereString))
                {
                    queryString += " where " + whereString;
                }
                queryString += " order by username";

                cmd.CommandText = queryString;
                cmd.Connection.Open();

                var dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    userList.Add(new AdminUserInfo()
                    {
                        Id = Guid.Parse(dr["id"].ToString()),
                        UserName = dr["username"].ToString(),
                        Email = dr["email"].ToString(),
                        Password = dr["password"].ToString()
                    });
                }
                dr.Close();
            }

            return userList;
        }
        
        public void DeleteAdminUser(Guid adminUserId)
        {
            using (var conn = new SqlConnection(_dbConnString))
            {
                var cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandText = "delete sysadmin where id=@id";
                cmd.Parameters.AddWithValue("@id", adminUserId);
                cmd.Connection.Open();
                cmd.ExecuteNonQuery();
            }
        }
        public void UpdateAdminUser(AdminUserInfo adminUserInfo)
        {
            using (var conn = new SqlConnection(_dbConnString))
            {
                var cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandText = "update sysadmin set email=@email,modifydate=getdate() where id=@id";
                cmd.Parameters.AddWithValue("@id", adminUserInfo.Id);

                if (string.IsNullOrEmpty(adminUserInfo.Email))
                {
                    cmd.Parameters.AddWithValue("@email", DBNull.Value);
                }
                else
                {
                    cmd.Parameters.AddWithValue("@email", adminUserInfo.Email);
                }
                cmd.Connection.Open();
                cmd.ExecuteNonQuery();
            }
        }
        public void CreateAdminUser(AdminUserInfo adminUserInfo)
        {
            using (var conn = new SqlConnection(_dbConnString))
            {
                var cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandText = @"insert into sysadmin (id,username,password,email,initdate) 
                                    values(@id,@username,@password,@email,getdate()) ";
                cmd.Parameters.AddWithValue("@id", adminUserInfo.Id);
                cmd.Parameters.AddWithValue("@username", adminUserInfo.UserName);
                cmd.Parameters.AddWithValue("@password", adminUserInfo.Password);

                if (string.IsNullOrEmpty(adminUserInfo.Email))
                {
                    cmd.Parameters.AddWithValue("@email", DBNull.Value);
                }
                else
                {
                    cmd.Parameters.AddWithValue("@email", adminUserInfo.Email);
                }


                cmd.Connection.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }

    public class AdminUserQueryParameter
    {
        public string UserName { get; set; }
        public string Email { get; set; }
        public string Tel { get; set; }

    }
}
