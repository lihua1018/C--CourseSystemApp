﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;

namespace CourseSystemLibrary.DbService
{
    public class StuScheduleRepository
    {
        private string _dbConnStr;
        public StuScheduleRepository(string dbConnStr)
        {
            _dbConnStr = dbConnStr;
        }

        public bool StuScheduleExist(Guid courseScheduleId)
        {
            //using (var conn = new SqlConnection(_dbConnStr))
            //{
            //    var cmd = new SqlCommand();
            //    cmd.CommandText = "select count(*) as cnt from stucourseschedule where cscheduleid=@coursescheduleid";
            //    cmd.Parameters.AddWithValue("@coursescheduleid", courseScheduleId);
            //    cmd.Connection = conn;
            //    conn.Open();
            //    var sqldr = cmd.ExecuteReader();
            //    var cnt = 0;
            //    if (sqldr.Read())
            //    {
            //        cnt = Convert.ToInt32(sqldr["cnt"]);
            //    }
            //    return cnt > 0;
            //}

            using (var conn = new SqlConnection(_dbConnStr))
            {
                var cmd = new SqlCommand();
                cmd.CommandText = "select count(*) from stucourseschedule where cscheduleid=@coursescheduleid";
                cmd.Parameters.AddWithValue("@coursescheduleid", courseScheduleId);
                cmd.Connection = conn;
                conn.Open();
                var cnt = (int)cmd.ExecuteScalar();
                return cnt > 0;
            }
        }
    }
}
