﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourseSystemLibrary.DataModels;

namespace CourseSystemLibrary.DbService
{
    public class TeacherRepository
    {
        private string _dbConnStr;
        public TeacherRepository(string dbConnStr)
        {
            _dbConnStr = dbConnStr;
        }

        public ObservableCollection<TeacherInfo> Query()
        {
            var teacherList = new ObservableCollection<TeacherInfo>();

            using (var conn = new SqlConnection(_dbConnStr))
            {
                var cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandText = "select id,name,email,mobile from teacher";
                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    teacherList.Add(new TeacherInfo()
                    {
                        Id = Guid.Parse(dr["id"].ToString()),
                        Name = dr["name"].ToString(),
                        Email = dr["email"].ToString(),
                        Mobile = dr["mobile"].ToString()
                    });
                }
                dr.Close();
            }
            return teacherList;
        }
    }
}
