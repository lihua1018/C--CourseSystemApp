﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourseSystemLibrary.DataModels;

namespace CourseSystemLibrary.DbService
{
    public class CourseRepository
    {
        private string _dbConnStr;

        public CourseRepository(string dbConnStr)
        {
            _dbConnStr = dbConnStr;
        }
        public ObservableCollection<CourseInfo> Query()
        {
            var courseList = new ObservableCollection<CourseInfo>();

            using (var conn = new SqlConnection(_dbConnStr))
            {
                var cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandText = "select id,code,name,times,description from course";
                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    courseList.Add(new CourseInfo()
                    {
                        Id = Guid.Parse(dr["id"].ToString()),
                        Name = dr["name"].ToString(),
                        Code = dr["code"].ToString(),
                        Description = dr["description"].ToString(),
                        Times = int.Parse(dr["times"].ToString())
                    });
                }
                dr.Close();
            }
            return courseList;
        }
    }
}
